// var x = 100;
// //x = "Hello !";
// console.log(x);

// // if(true){
// //     let y = 200;

// //         if(true){
// //             console.log(y); // nested
// //         }

// // }

// const PI = 3.14;
// // PI = 3.14236; // Error !

// let str ; // declaration
// str = "Hello !"; // defn


let x:number =100;

function Addition(x:number,y:number):number{
        return x + y;
}

var result:number = Addition(10,20);

let aVar:any;
aVar = 10;
aVar = true;
aVar = "Bye !";

aVar = {Name:'Synechron',Location:'Pune'};


