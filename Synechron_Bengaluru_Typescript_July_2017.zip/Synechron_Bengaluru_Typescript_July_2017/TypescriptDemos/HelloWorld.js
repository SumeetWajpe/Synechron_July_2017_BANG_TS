// var x = 100;
// //x = "Hello !";
// console.log(x);
// // if(true){
// //     let y = 200;
// //         if(true){
// //             console.log(y); // nested
// //         }
// // }
// const PI = 3.14;
// // PI = 3.14236; // Error !
// let str ; // declaration
// str = "Hello !"; // defn
var x = 100;
function Addition(x, y) {
    return x + y;
}
var result = Addition(10, 20);
