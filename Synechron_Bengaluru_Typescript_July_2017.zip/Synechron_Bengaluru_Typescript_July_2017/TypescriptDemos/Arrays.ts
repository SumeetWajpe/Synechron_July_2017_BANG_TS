

var cars:string[] = ['BMW','Audi','Honda','Hyundai'];
var books:any[] = ['3 Mistakes',200,'Colour',false];
// var moreCars:Array<string> = new Array<string>();

for(let car in cars){
    console.log(cars[car]);  // car is index
}

for(let car of cars){
    console.log(car);
}


