enum Designations{
    Developer,
    Tester,
    Manager,
    Trainer,
    Achitect
}

let myDesgn:Designations;
myDesgn = Designations.Trainer;
console.log(myDesgn); // numeric Value
console.log(Designations[myDesgn]);