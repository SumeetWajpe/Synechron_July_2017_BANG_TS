var cars = ['BMW', 'Audi', 'Honda', 'Hyundai'];
// var moreCars:Array<string> = new Array<string>();
for (var car in cars) {
    console.log(cars[car]); // car is index
}
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var car = cars_1[_i];
    console.log(car);
}
