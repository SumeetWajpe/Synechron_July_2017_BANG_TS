


enum Category{
    Fiction,
    Comedy,
    Inspirational,
    Autobiography
}


interface IBook{
        title:string;
        author:string;
        price:number;
        available:boolean;
        category:Category;
}
function GetAllBooks():IBook[]{
let books:IBook[]=[
    {title:'Wings Of Fire',price:300,author:'Dr. APJ Abdul Kalam',available:false,category:Category.Inspirational},
    {title:'I am Malala',price:700,author:'Malala',available:false,category:Category.Autobiography},
    {title:'Playing It My Way',price:300,author:'Sachin Tendulkar',available:true,category:Category.Autobiography},
    {title:'Mrutunjay',price:600,author:'Ranjit Desai',available:false,category:Category.Fiction},
    {title:'Chava',price:300,author:'Ranjit Desai',available:true,category:Category.Inspirational}
    ];
 return books;
}
let allBooks:IBook[] = GetAllBooks();

for(let book of allBooks){
    console.log(book.title + ' is costing Rs.' + book.price)
}

function    GetFirstAvailableBook(books:any[]):void{
for(let book of books){
    if(book.available === true){
    console.log(book.title);
    break;
    }
}
}
GetFirstAvailableBook(allBooks);

function    GetBooksByCategory(categoryFilter:Category):string[]{
console.log('Getting books for Category : ' + Category[categoryFilter]);
let filteredBooks:string[] = [];
    for(let currBook of allBooks){
        if(currBook.category === categoryFilter){
            filteredBooks.push(currBook.title);
        }
    }
return filteredBooks;
}

let biographyBooks:string[] = GetBooksByCategory(Category.Autobiography)
// for(let book of biographyBooks){
//     console.log(book);
// }

// biographyBooks.forEach(function(book,index){
//     console.log(book);
// });

//biographyBooks.forEach((book,index)=>{ console.log(book);});


function Square(x){
    return x * x;
}
// function as an expression !
var Square1=function(x){
    return x * x;
}

//let r = Square1('Hello');
//console.log('R value : ' + r);
// Arrow functions
var Square2 = x =>  x * x;

var IdGenerator:(str_id:number,str_name:string)=>string; // Function Type

// IdGenerator = function(id:number,name:string):string{

// }


function   ProductIdGen(id:number,name:string):string{
    return id + name;
}

IdGenerator = ProductIdGen;
let Identifier:string = IdGenerator(10,'XYZ');


function   EmpIdGen(id:number,name:string):string{
    return id + name;
}

IdGenerator = EmpIdGen;

// Default Parameters
// function    Print(noOfPage:number=100,author:string="Vague",city:string="Pune"){
//     console.log(noOfPage,author,city);
// }

// Print(100,"C K Patel","Ahmedabad");

// Optional Parameters

// function Print(noOfPages:number,author:string="M K Patel",city?:string){

// console.log(noOfPages,author);
// if(city){
//     console.log(city);
// }
// }

// Print(1000,undefined,"Goa");

// Rest Parameters

// function Print(noOfPages:number,...restOfArgs:any[]){
//         console.log(restOfArgs.length);
// }

// Print(100);
// Print(100,"Don Shori","Goa");
// Print(100,"Don Shori","Goa","Rk Publication",410508);

// De-structuring
var cars:string[] = ['BMW','Audi','Honda','Hyundai'];

let carOne:string,carTwo:string;
// carOne = cars[0];
// carTwo = cars[1];

[carOne,,carTwo] = ['BMW','Audi','Honda','Hyundai'];

let weekdays:string[] = ['mon','tue','wed','thr','fri'];
let weekends:string[] = ['sat','sun'];

let week = [...weekdays,...weekends]; // ... Spread Operator
//console.log(week);


// function Test(){

// }

//let r:void = Test();

// Type assertions (Compatibility)

let someValue:any = 100;

//let len:number = (<string>someValue).length;
let len:number = (someValue as string).length;
//console.log(len);

// Destructuring with Objects
let person:any = {Name:'Sumeet',Age:32,City:'Pune'};

let {Name,City} = person;
//console.log(Name);

function GetTitles(availability:boolean):string[];
function GetTitles(categoryFilter:Category):string[];
function GetTitles(bookProperty:any,author?:string):string[]{
let booksToBeReturned:string[];

if(typeof bookProperty == "boolean"){
    for(let book of allBooks){
        if(book.available == bookProperty){
            booksToBeReturned.push(book.title)
        }
    }
}

if(typeof bookProperty == "number"){
    for(let book of allBooks){
        if(book.category == bookProperty){
            booksToBeReturned.push(book.title)
        }
    }
}

return booksToBeReturned;
}

//let retBooks =  GetTitles()

interface Person{
    name:string;
    email:string;
    age:number;
    location?:string;
    get_Details:() => void;
}

let p:Person;
 p ={
     name:'Tejas',
    age:24,
    email:'tejas@gmail.com',
    get_Details:function() {
         console.log(this.name + " : " + this.email);
    }
};

p.get_Details();

interface Employee extends Person{
    empId:number;
}

var emp:Employee;
emp = {
     name:'Tejas',
    age:24,
    email:'tejas@gmail.com',
    get_Details:function() {
         console.log(this.name + " : " + this.email);
    },
    empId:1
}

// Classes


// class Car{
//    private id:number;
//     name:string;
//     speed:number;

//     constructor();
//     constructor(theId:number,theName:string,theSpeed:number);
//      constructor(theId?:any,theName?:any,theSpeed?:any){
//             this.id = theId;
//             this.name = theName;
//             this.speed = theSpeed;
//     }
// Accelerate():void{
//     console.log(`The car ${this.name} running @ ${this.speed} kmph !`)
// }
// }

// let carone:Car;
// carone = new Car();
// carone.name = "i20";
// carone.speed = 200;
// //console.log('The car ' + carone.name + ' running @ ' + carone.speed + ' kmph !')
// console.log(`The car ${carone.name} running @ ${carone.speed} kmph !`)

//let c = new Car(1,"i30",300); // parameterized
//let c1 = new Car(); // default constructor

// class Car{
  

//    constructor(private Id:number,private Name:string,private Speed:number){
         
//     }
// }

class Car{
       private id:number;
       protected name:string;
        speed:number;        
    constructor(theId:number,theName:string,theSpeed:number){
            this.id = theId;
            this.name = theName;
            this.speed = theSpeed;
    }

    Accelerate():string{
    return (`The car ${this.name} running @ ${this.speed} kmph !`);
}
}

class BatmanCar extends Car{
    useNitroPower:boolean;
constructor(theId:number,theName:string,theSpeed:number,theNitro:boolean){         
           super(theId,theName,theSpeed);  
            this.useNitroPower = theNitro;
    }
    Accelerate():string{
        return super.Accelerate() + ' using Nitropower ? : ' +this.useNitroPower
    }
}

let b = new BatmanCar(8,"Houston",500,true);


interface IPerson{
    name:string;
    email:string;
    age:number;
    location?:string;
    get_Details:() => void;
}

interface Employee extends Person{
    empId:number;
}




class CPerson extends  Car implements IPerson{
     name:string;
    email:string;
    age:number;
    location?:string;
    get_Details():void{
        console.log(this.name + " is of " + this.age);
    };
}


class Manager extends CPerson{

}

class ActingManager{

}

class Company<T extends CPerson>{

}

let comp = new Company<CPerson>();

// let c = new CPerson();
// c.name = "Aniket";
// c.age = 15;
// c.get_Details();


let carsArray:Array<string>;
carsArray = new Array<string>();
//carsArray[0] = 100;


function  Swap<T>(x:T,b:T){
        let temp:T;
        temp = x;
       x = b;
        b = temp;
}

Swap<string>("Hello","Hi");


class Point<T>{
        x:T;
        y:T;
}


// let point = new Point<number>();
// point.x = 10;
// console.log(typeof point.x);
