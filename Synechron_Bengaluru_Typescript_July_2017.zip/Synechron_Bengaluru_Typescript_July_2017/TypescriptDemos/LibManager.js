var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Category;
(function (Category) {
    Category[Category["Fiction"] = 0] = "Fiction";
    Category[Category["Comedy"] = 1] = "Comedy";
    Category[Category["Inspirational"] = 2] = "Inspirational";
    Category[Category["Autobiography"] = 3] = "Autobiography";
})(Category || (Category = {}));
function GetAllBooks() {
    var books = [
        { title: 'Wings Of Fire', price: 300, author: 'Dr. APJ Abdul Kalam', available: false, category: Category.Inspirational },
        { title: 'I am Malala', price: 700, author: 'Malala', available: false, category: Category.Autobiography },
        { title: 'Playing It My Way', price: 300, author: 'Sachin Tendulkar', available: true, category: Category.Autobiography },
        { title: 'Mrutunjay', price: 600, author: 'Ranjit Desai', available: false, category: Category.Fiction },
        { title: 'Chava', price: 300, author: 'Ranjit Desai', available: true, category: Category.Inspirational }
    ];
    return books;
}
var allBooks = GetAllBooks();
for (var _i = 0, allBooks_1 = allBooks; _i < allBooks_1.length; _i++) {
    var book = allBooks_1[_i];
    console.log(book.title + ' is costing Rs.' + book.price);
}
function GetFirstAvailableBook(books) {
    for (var _i = 0, books_1 = books; _i < books_1.length; _i++) {
        var book = books_1[_i];
        if (book.available === true) {
            console.log(book.title);
            break;
        }
    }
}
GetFirstAvailableBook(allBooks);
function GetBooksByCategory(categoryFilter) {
    console.log('Getting books for Category : ' + Category[categoryFilter]);
    var filteredBooks = [];
    for (var _i = 0, allBooks_2 = allBooks; _i < allBooks_2.length; _i++) {
        var currBook = allBooks_2[_i];
        if (currBook.category === categoryFilter) {
            filteredBooks.push(currBook.title);
        }
    }
    return filteredBooks;
}
var biographyBooks = GetBooksByCategory(Category.Autobiography);
// for(let book of biographyBooks){
//     console.log(book);
// }
// biographyBooks.forEach(function(book,index){
//     console.log(book);
// });
//biographyBooks.forEach((book,index)=>{ console.log(book);});
function Square(x) {
    return x * x;
}
// function as an expression !
var Square1 = function (x) {
    return x * x;
};
//let r = Square1('Hello');
//console.log('R value : ' + r);
// Arrow functions
var Square2 = function (x) { return x * x; };
var IdGenerator; // Function Type
// IdGenerator = function(id:number,name:string):string{
// }
function ProductIdGen(id, name) {
    return id + name;
}
IdGenerator = ProductIdGen;
var Identifier = IdGenerator(10, 'XYZ');
function EmpIdGen(id, name) {
    return id + name;
}
IdGenerator = EmpIdGen;
// Default Parameters
// function    Print(noOfPage:number=100,author:string="Vague",city:string="Pune"){
//     console.log(noOfPage,author,city);
// }
// Print(100,"C K Patel","Ahmedabad");
// Optional Parameters
// function Print(noOfPages:number,author:string="M K Patel",city?:string){
// console.log(noOfPages,author);
// if(city){
//     console.log(city);
// }
// }
// Print(1000,undefined,"Goa");
// Rest Parameters
// function Print(noOfPages:number,...restOfArgs:any[]){
//         console.log(restOfArgs.length);
// }
// Print(100);
// Print(100,"Don Shori","Goa");
// Print(100,"Don Shori","Goa","Rk Publication",410508);
// De-structuring
var cars = ['BMW', 'Audi', 'Honda', 'Hyundai'];
var carOne, carTwo;
// carOne = cars[0];
// carTwo = cars[1];
_a = ['BMW', 'Audi', 'Honda', 'Hyundai'], carOne = _a[0], carTwo = _a[2];
var weekdays = ['mon', 'tue', 'wed', 'thr', 'fri'];
var weekends = ['sat', 'sun'];
var week = weekdays.concat(weekends); // ... Spread Operator
//console.log(week);
// function Test(){
// }
//let r:void = Test();
// Type assertions (Compatibility)
var someValue = 100;
//let len:number = (<string>someValue).length;
var len = someValue.length;
//console.log(len);
// Destructuring with Objects
var person = { Name: 'Sumeet', Age: 32, City: 'Pune' };
var Name = person.Name, City = person.City;
function GetTitles(bookProperty, author) {
    var booksToBeReturned;
    if (typeof bookProperty == "boolean") {
        for (var _i = 0, allBooks_3 = allBooks; _i < allBooks_3.length; _i++) {
            var book = allBooks_3[_i];
            if (book.available == bookProperty) {
                booksToBeReturned.push(book.title);
            }
        }
    }
    if (typeof bookProperty == "number") {
        for (var _a = 0, allBooks_4 = allBooks; _a < allBooks_4.length; _a++) {
            var book = allBooks_4[_a];
            if (book.category == bookProperty) {
                booksToBeReturned.push(book.title);
            }
        }
    }
    return booksToBeReturned;
}
var p;
p = {
    name: 'Tejas',
    age: 24,
    email: 'tejas@gmail.com',
    get_Details: function () {
        console.log(this.name + " : " + this.email);
    }
};
p.get_Details();
var emp;
emp = {
    name: 'Tejas',
    age: 24,
    email: 'tejas@gmail.com',
    get_Details: function () {
        console.log(this.name + " : " + this.email);
    },
    empId: 1
};
// Classes
// class Car{
//    private id:number;
//     name:string;
//     speed:number;
//     constructor();
//     constructor(theId:number,theName:string,theSpeed:number);
//      constructor(theId?:any,theName?:any,theSpeed?:any){
//             this.id = theId;
//             this.name = theName;
//             this.speed = theSpeed;
//     }
// Accelerate():void{
//     console.log(`The car ${this.name} running @ ${this.speed} kmph !`)
// }
// }
// let carone:Car;
// carone = new Car();
// carone.name = "i20";
// carone.speed = 200;
// //console.log('The car ' + carone.name + ' running @ ' + carone.speed + ' kmph !')
// console.log(`The car ${carone.name} running @ ${carone.speed} kmph !`)
//let c = new Car(1,"i30",300); // parameterized
//let c1 = new Car(); // default constructor
// class Car{
//    constructor(private Id:number,private Name:string,private Speed:number){
//     }
// }
var Car = (function () {
    function Car(theId, theName, theSpeed) {
        this.id = theId;
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        return ("The car " + this.name + " running @ " + this.speed + " kmph !");
    };
    return Car;
}());
var BatmanCar = (function (_super) {
    __extends(BatmanCar, _super);
    function BatmanCar(theId, theName, theSpeed, theNitro) {
        var _this = _super.call(this, theId, theName, theSpeed) || this;
        _this.useNitroPower = theNitro;
        return _this;
    }
    BatmanCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + ' using Nitropower ? : ' + this.useNitroPower;
    };
    return BatmanCar;
}(Car));
var b = new BatmanCar(8, "Houston", 500, true);
var CPerson = (function (_super) {
    __extends(CPerson, _super);
    function CPerson() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CPerson.prototype.get_Details = function () {
        console.log(this.name + " is of " + this.age);
    };
    ;
    return CPerson;
}(Car));
var Manager = (function (_super) {
    __extends(Manager, _super);
    function Manager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Manager;
}(CPerson));
var ActingManager = (function () {
    function ActingManager() {
    }
    return ActingManager;
}());
var Company = (function () {
    function Company() {
    }
    return Company;
}());
var comp = new Company();
// let c = new CPerson();
// c.name = "Aniket";
// c.age = 15;
// c.get_Details();
var carsArray;
carsArray = new Array();
//carsArray[0] = 100;
function Swap(x, b) {
    var temp;
    temp = x;
    x = b;
    b = temp;
}
Swap("Hello", "Hi");
var Point = (function () {
    function Point() {
    }
    return Point;
}());
var _a;
// let point = new Point<number>();
// point.x = 10;
// console.log(typeof point.x);
