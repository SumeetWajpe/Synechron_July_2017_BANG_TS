var Designations;
(function (Designations) {
    Designations[Designations["Developer"] = 0] = "Developer";
    Designations[Designations["Tester"] = 1] = "Tester";
    Designations[Designations["Manager"] = 2] = "Manager";
    Designations[Designations["Trainer"] = 3] = "Trainer";
    Designations[Designations["Achitect"] = 4] = "Achitect";
})(Designations || (Designations = {}));
var myDesgn;
myDesgn = 10;
console.log(myDesgn); // numeric Value
console.log(Designations[myDesgn]);
