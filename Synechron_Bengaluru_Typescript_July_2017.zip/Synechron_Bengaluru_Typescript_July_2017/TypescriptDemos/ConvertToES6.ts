let someVar = 100;

function   TakesInAny(x):void{

}

