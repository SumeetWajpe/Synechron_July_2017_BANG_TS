"use strict";
var Math_1 = require('./Math');
console.log('The addition is : ' + Math_1.default(20, 30));
