"use strict";
function Add(x, y) {
    return x + y;
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Add;
