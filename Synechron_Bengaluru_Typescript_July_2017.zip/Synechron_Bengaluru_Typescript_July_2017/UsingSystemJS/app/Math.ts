﻿
function Add(x: number, y: number): number {
    return x + y;
}

export default Add;