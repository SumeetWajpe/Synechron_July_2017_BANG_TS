﻿(function(global){

    System.config({
        transpiler: 'typescript',
        map: {
            app:'app'
        },
        // packages tells System JS how to load our modules
        packages: {
            app: {
                main: './Calculator.js',
                defaultExtension:'js'
            }
        }
    })

})(this)